fx_version 'cerulean'

game 'gta5'

description 'vPrompt'

author 'Mobius1'

version '1.0.0'

client_script 'vprompt.lua'